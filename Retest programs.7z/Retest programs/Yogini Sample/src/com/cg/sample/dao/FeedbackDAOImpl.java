package com.cg.sample.dao;

import java.util.HashMap;

import com.cg.sample.bean.Trainer;
import com.cg.sample.util.DBUtil;

public class FeedbackDAOImpl implements FeedbackDAO
{
	int feedback_id;
	HashMap<Integer,Trainer> map;
	
	public  FeedbackDAOImpl() 
	{
		map=DBUtil.getFeedbackList();
	}
	@Override
	public void addFeedback(Trainer trainer)
	{
		feedback_id= (int) (Math.random()*1000);
		map.put(feedback_id, trainer);
		System.out.println(map);
		
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList()
	{
		
		return map;
	}

}
