package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccountDao accountDao= new AccountDaoImpl();
		AccountService service = new AccountServiceImpl(accountDao);

		int choice = 0;

		while(true){
//			This is to display the menu
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");

			choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {
			case 1:
				
				System.out.println("Enter Mobile No: ");
				String mobNo = sc.nextLine();
				validateMobNo(mobNo);

				try {
					Account acc = service.getAccountDetails(mobNo);
					System.out.println("Your Current Balance is Rs. "+acc.getAccountBalance());
				}
				catch (MobileRechargeException e) {
					
					e.getMessage();
				}
				break;

			case 2:
				//case2: is to take input from user and recharge the account and display the current balance
				
				System.out.println("Enter MobileNo: ");
				String mobileNo = sc.nextLine();
				try {
				if(!validateMobNo(mobileNo))
						throw new MobileRechargeException("Inavlid Mobile Number...");
				
					} catch (MobileRechargeException e) {
					
						e.getMessage();
					}
				System.out.println("Enter Recharge Amount: ");
				double reAmt = sc.nextDouble();
				sc.hasNextLine();
				
				try {
					if(!validateAmount(reAmt))
						throw new MobileRechargeException("Invalid amount entered...");
					}
				catch (MobileRechargeException e) {
				
						e.getMessage();
					}
				
				try {
					String result=service.rechargeAccount(mobileNo, reAmt);
					System.out.println(result);
					
				} catch (MobileRechargeException e) {
					
					e.getMessage();
				}
				break;
				
			case 3:
					System.out.println("Exited...");
					System.exit(0);
					break;

			default:System.out.println("Wrong choice! Please select the correct choice");
					break;
			
			}

		}
	}
	
	public static boolean validateMobNo(String mobNo) {
		Pattern pat = Pattern.compile("[6-9][0-9]{9}");
		Matcher mat = pat.matcher(mobNo);
		if(mat.matches()) {
			return true;
		}
		else {
			System.out.println("Please enter valid mobile number:");
			String mob= sc.nextLine();
			validateMobNo(mob);
		}
		return true;
	}

	//Method to validate the amount
	
	public static boolean validateAmount(double reAmt) {
		// TODO Auto-generated method stub
		Pattern pat = Pattern.compile("[1-9][0-9.]{0,15}");
		Matcher mat = pat.matcher(String.valueOf(reAmt));
		return mat.matches();
	}

}
