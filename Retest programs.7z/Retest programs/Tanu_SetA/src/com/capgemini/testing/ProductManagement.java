package com.capgemini.testing;

import org.junit.jupiter.api.Test;

class ProductManagement {


}
