package com.cap.exception;

public class ProductIdInvalidException extends Exception {

}
