package com.capgemini.Exception;

public class IdNotgivenException extends Exception {

}
