package Exceptions;

public class InvalidAddressException extends Exception {

}
