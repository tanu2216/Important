package Exceptions;

public class EmployeeAlreadyExistException extends Exception {

}
