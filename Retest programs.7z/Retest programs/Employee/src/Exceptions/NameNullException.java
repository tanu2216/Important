package Exceptions;

public class NameNullException extends Exception {

}