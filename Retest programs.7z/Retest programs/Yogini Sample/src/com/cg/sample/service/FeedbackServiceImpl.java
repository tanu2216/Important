package com.cg.sample.service;

import java.util.HashMap;

import com.cg.sample.bean.Trainer;
import com.cg.sample.dao.FeedbackDAO;
import com.cg.sample.dao.FeedbackDAOImpl;

public class FeedbackServiceImpl implements FeedbackService
{
    FeedbackDAO daoref=new FeedbackDAOImpl();
	
    @Override
	public void addFeedback(Trainer trainer)
	{
		daoref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return daoref.getTrainerList();
	}
}
