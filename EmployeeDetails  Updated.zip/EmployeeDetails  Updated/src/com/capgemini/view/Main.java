package com.capgemini.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.capgemini.Exception.AddressNotGivenException;
import com.capgemini.Exception.DuplicateIdException;
import com.capgemini.Exception.IdNotgivenException;
import com.capgemini.Exception.NameNotFindException;
import com.capgemini.Exception.NameNotGivenException;
import com.capgemini.beans.Address;
import com.capgemini.beans.City;
import com.capgemini.beans.Country;
import com.capgemini.beans.Employee;
import com.capgemini.repository.EmployeeRepo;
import com.capgemini.repository.EmployeeRepoImp;
import com.capgemini.service.EmployeeService;

public class Main {
	
	public static void main(String[] args)  {
		
		EmployeeRepo empRepo = new EmployeeRepoImp();
		EmployeeService empService  = new EmployeeService(empRepo);
		Scanner sc= new Scanner(System.in);
		
		while (true) {
			
			int choice=0;
			System.out.println("Enter your choice:");
			System.out.println("1. Add Employee");
			System.out.println("2. Show Employee By Name");
			System.out.println("3. Exit");
			choice= sc.nextInt();
			sc.nextLine();
			switch(choice) {
			
			case 1: System.out.println("Enter Employee ID:");
					String e_id=sc.nextLine();
					System.out.println("Enter Employee Name:");
					String e_name= sc.nextLine();
					System.out.println("please enter Addres Details:");
					System.out.println("Enter AddressLine :");
					String ad_line=sc.nextLine();
					System.out.println("Enter City :");
					String city= sc.nextLine();
					System.out.println("Enter Country :");
					String country= sc.nextLine();
					Address ad=new Address();
					Country ad_country= new Country();
					City c = new City();
					ad.setAddressLine("383");
					ad.setCountry(ad_country);
					ad_country.setCountryName(country);
					ad_country.setCity(c);
					c.setCityName(city);
					try {
						boolean a;
						a =  empService.createEmployee(e_id,e_name,ad);
						
						if(a)
							System.out.println("Employee added successfully");
						else
							System.out.println("Error occurred");
						
					} catch (NameNotGivenException e) {

						e.getMessage();
						
					}
					catch (IdNotgivenException e) {
						e.getMessage();
					}
					catch (AddressNotGivenException e) {
						
						e.getMessage();
						
					} catch (DuplicateIdException e) {
						
						e.printStackTrace();
					}
					break;
			case 2: System.out.println("Enter employee name you want to search:");
					String searchName= sc.nextLine();
					List<Employee> list = new ArrayList<Employee>();
					
					try {
						list=empService.searchByName(searchName);
						if(list==null)
							System.out.println(" ");
						else {
							for(int i=0;i<list.size();i++)
								System.out.println(list.get(i));		
						}
						
					} 
					catch (NameNotFindException e) {
						
						e.getMessage();
						
					} catch (NameNotGivenException e) {
						
						e.printStackTrace();
						
					}			
					break;
			case 3: System.exit(0);
					break;
					
			default: System.out.println("Wrong choice");
					break;
			
			}
			
		}
	}
		 
}
