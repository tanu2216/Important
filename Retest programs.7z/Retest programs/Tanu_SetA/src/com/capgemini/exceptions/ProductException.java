package com.capgemini.exceptions;
@SuppressWarnings("serial")
public class ProductException extends Exception {
	

}
