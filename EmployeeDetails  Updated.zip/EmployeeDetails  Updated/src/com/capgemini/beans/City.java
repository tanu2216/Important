package com.capgemini.beans;

public class City {
	
	private String cityname;

	public String getCityName() {
		return cityname;
	}

	public void setCityName(String city) {
		this.cityname = city;
	}

	public City(String cityname) {
		super();
		this.cityname = cityname;
	}

	public City() {
		super();
	}

	@Override
	public String toString() {
		return "City [city=" + cityname + "]";
	}
	
	
}
