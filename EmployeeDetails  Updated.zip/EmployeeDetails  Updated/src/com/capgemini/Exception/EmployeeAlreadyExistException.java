package com.capgemini.Exception;

public class EmployeeAlreadyExistException extends Exception {

}
