package com.cg.sample.ui;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import com.cg.sample.bean.Trainer;
import com.cg.sample.service.FeedbackService;
import com.cg.sample.service.FeedbackServiceImpl;

public class Client {

	public static void main(String[] args)
	{
		FeedbackService serref=new FeedbackServiceImpl();
		Scanner scanner=new Scanner(System.in);
		HashMap<Integer,Trainer> map= new HashMap<Integer,Trainer>();
		int choice;
		
		System.out.println("1.Store the details of trainer");
		System.out.println("2. Display ");
		System.out.println("3. Exit");
		
		do {
			System.out.println("Enter your choice");
			 choice= scanner.nextInt();
		switch(choice)
		{
		case 1: {
			     System.out.println("Enter the name of trainer:");
			     String name=scanner.next();
			     System.out.println("Enter the course name");
			     String cname=scanner.next();
			     System.out.println("Enter the starting date in dd-MM-yyyy format");
			     String sdate=scanner.next();
			     System.out.println("Enter the ending date in dd-MM-yyyy format");
			     String edate=scanner.next();
			     System.out.println("Enter the rating");
			     int rating=scanner.nextInt();
			     
			     Trainer trn= new Trainer(name,cname,sdate,edate,rating);
			     serref.addFeedback(trn);
			     System.out.println("Data is feed into map");
			
		        }
		        break;
		case 2:{
			     System.out.println("Enter the rating");
			     int rating=scanner.nextInt();
			     
			     map=serref.getTrainerList();
			     for(Entry<Integer,Trainer> x:map.entrySet()) 
			     {
			    	if(x.getValue().getRating()==rating)
			    	{
			    		System.out.println(x.getKey()+"\t"+x.getValue());
			    	}
			     }
		}
		}
		
      	
	}while(choice!=3);
	}


}
