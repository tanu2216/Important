package com.capgemini.exceptions;

import com.capgemini.salesmanagement.bean.Sale;

public class SalesException extends Sale{

}
