package com.capgemini.Exception;

public class NameNotGivenException extends Exception {

}
