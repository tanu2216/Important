package Exceptions;

public class EmployeeDoesNotExistException extends Exception {

}
