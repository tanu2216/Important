package com.capgemini.beans;

public class Country {
	
	private String  countryname;
	private City city;
	
	public String getcountryName() {
		return countryname;
	}
	public void setCountryName(String name) {
		this.countryname = name;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}
	public Country() {
		super();
	}
	public Country(String countryname, City city) {
		super();
		this.countryname = countryname;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Country [name=" + countryname + ", city=" + city + "]";
	}
	
	
}
