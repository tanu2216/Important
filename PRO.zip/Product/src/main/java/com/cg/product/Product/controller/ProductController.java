package com.cg.product.Product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.Product.bean.Product;
import com.cg.product.Product.service.IProductService;

@RestController
public class ProductController {
	
	@Autowired
	IProductService service;

	public IProductService getService() {
		return service;
	}

	public void setService(IProductService service) {
		this.service = service;
	}
	
	@RequestMapping(value="/addProduct",method=RequestMethod.POST,
			produces="application/json",consumes="application/json")
	
	public Product addProduct(@RequestBody Product product)
	{
		service.addProduct(product);
		return product;
		
}
	@RequestMapping(value="/getProductById/{prodId}",method=RequestMethod.GET,
			produces="application/json")
	public Product getById(@PathVariable int prodId)
	{
		Product product=service.getById(prodId);
		return product;
	}
	
	@RequestMapping(value="/updateProduct",method=RequestMethod.POST,
			consumes="application/json",produces="application/json")
	public Product updateProduct(@RequestBody Product product)
	{
		product=service.updateProduct(product);
		return product;
		
	}
	@RequestMapping(value="/deleteProduct/{prodId}",method=RequestMethod.GET,
			produces="application/json")
	public Product deleteProduct(@PathVariable int prodId)
	{
		return service.deleteProduct(prodId);
	}
	@RequestMapping(value="/getAllProduct",produces="application/json")
	public List<Product> getAllProduct()
	{
		return service.getAllProduct();
		
	}
	@RequestMapping(value="/getProductByBrand/{prodBrand}",method=RequestMethod.GET,
			produces="application/json")
	public List<Product> getByBrand(@PathVariable String prodBrand)
	{
		List<Product> product=service.getByBrand(prodBrand);
		return product;
	}
	
	@RequestMapping(value="/getByPriceRange",method=RequestMethod.GET,
			produces="application/json")
	public List<Product> getByPriceRange(@RequestParam(value="min") float min,@RequestParam(value="max") float max)
	{
		List<Product> product=service.getByPriceRange(min, max);
		return product;
	}
}
