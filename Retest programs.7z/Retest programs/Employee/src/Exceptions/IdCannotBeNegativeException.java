package Exceptions;

public class IdCannotBeNegativeException extends Exception {

}
