package com.capgemini.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;
import com.capgemini.teakehome.exception.InvalidProductCodeException;

public class ProductDAO implements IProductDAO {
	
	HashMap<Integer, Product> products = CollectionUtil.getProducts();
	
	@Override
	public Product getProductDetails(int productCode) throws InvalidProductCodeException {
		
		if(products.containsKey(productCode))
			return products.get(productCode);
		
		throw new InvalidProductCodeException("Product code is not exist in the hashmap");

	}

}
