package com.capgemini.Exception;

public class NameNullException extends Exception {

}
