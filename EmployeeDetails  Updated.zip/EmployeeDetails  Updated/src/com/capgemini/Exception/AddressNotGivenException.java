package com.capgemini.Exception;

public class AddressNotGivenException extends Exception {

}
