package com.capgemini.salesmanagement.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.exceptions.ProductException;
import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleDAO{
	public HashMap<Integer, Sale> insertSalesdetails(Sale sale);

	boolean validateProductCode(int productId);

	boolean validateProductCat(String prodcat);

	boolean validateproductname(String prodName);

	boolean validateProductPrice(float price);

	}