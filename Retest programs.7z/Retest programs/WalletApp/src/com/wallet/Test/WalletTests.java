package com.wallet.Test;

public class WalletTests {

}
