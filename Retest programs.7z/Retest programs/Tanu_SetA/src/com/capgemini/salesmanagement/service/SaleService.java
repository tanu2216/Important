package com.capgemini.salesmanagement.service;

import java.util.Map;

import com.capgemini.exceptions.ProductException;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;

//import com.cg.productmgmt.dao.IProductDAO;
//import com.cg.productmgmt.exceptions.ProductException;

public class SaleService implements ISaleService{
 
	ISaleDAO iSaleDAO;	

	public int updateProducts(String category, int hikePrice) throws ProductException {
		
		Object iSaleDAO;
		int updated=updateProducts(category, hikePrice);
		
		return updated;
	}


	
	
	public Map<String, Integer> getProductDetails() throws ProductException {
		
	
		
		return getProductDetails();
	}

	public java.util.HashMap<Integer, Sale> insertSalesdetails(Sale sale) {
		// TODO Auto-generated method stub
		return null;
	}






	public boolean validateProductPrice1(int productCode) {
		// TODO Auto-generated method stub
		return false;
	}






	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		return false;
	}






	public boolean validateProductPrice(int productCode) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public boolean validateProductCode(int productId) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public boolean validateProductCat(String prodcat) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public boolean validateproductname(String prodName) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
