package com.cg.sample.service;

import java.util.HashMap;

import com.cg.sample.bean.Trainer;

public interface FeedbackService 
{
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();

}
